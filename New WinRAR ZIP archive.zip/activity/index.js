const Discord = require('discord.js')
const ketse = new Discord.Client()
const config = require('./config.json')
const disbut = require('discord=buttons')
const { MessageButton } = require('discord-buttons')

ketse.on('ready', () => {
    console.log(ketse.user.tag + " is online")
})

ketse.on("message", async(message) => {
    const prefix = config.prefix
    if (!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if(command === 'gamaw'){
        const embe = new Discord.MessageEmbed({
        "color": "RANDOM",
        "fields": [
        {
        "name": message.guild.name + '\u200B',
        "value": "\u200B\n**Για να δείξετε οτι είστε ενεργός τότε πατήστε στον πράσινο κύκλο\nΓια να δείξετε οτι είστε ανενεργός τότε πατήστε στον κόκκινο κύκλο\n\n> <:ketse:" + config.emojis.online + "> Εντός υπηρεσίας\n\n> <:ketse:" + config.emojis.offline + "> Εκτός υπηρεσιας**"
        }
        ]
        })
        
        const online = new disbut.MessageButton()
        .setEmoji(config.emojis.online)
        .setStyle("green")
        .setID("online")
        const offline = new disbut.MessageButton()
        .setEmoji("" + config.emojis.offline + "")
        .setStyle("red")
        .setID("offline")
        
        
        const buttons = new disbut.MessageActionRow()
        .addComponent(online)
        .addComponent(offline)
        
        message.channel.send({embed: embe, component: buttons})
        
        
        }
})


ketse.on("clickButton", async(button) => {
    if(button.id === 'online'){
        const status = db.get(`time_${button.guild.id}_${button.clicker.user.id}`)
        if(status) return button.reply.send({embed: new Discord.MessageEmbed({
        "description": "**<:ketse:" + config.emojis.online + ">Η κατάσταση σου είναι ήδη ενεργή<:ketse:" + config.emojis.online + ">**",
        "color": button.guild.members.cache.get(button.clicker.user.id).displayHexColor,
        "author": {
        "name": button.clicker.user.username,
        "url": "https://discord.com/users/"+ button.clicker.user.id,
        "icon_url": button.clicker.user.displayAvatarURL()
        }
        }), ephemeral: true
        })
        if(!status) {
        button.reply.send({embed: new Discord.MessageEmbed({
        "description": "**<:ketse:" + config.emojis.online + ">Η κατάσταση σου είναι ενεργή<:ketse:" + config.emojis.online + ">**",
        "color": button.guild.members.cache.get(button.clicker.user.id).displayHexColor,
        "author": {
        "name": button.clicker.user.username,
        "url": "https://discord.com/users/"+ button.clicker.user.id,
        "icon_url": button.clicker.user.displayAvatarURL()
        }
        }), ephemeral: true})
        
        db.set(`time_${button.guild.id}_${button.clicker.user.id}`, new Date().getTime())
        }
        }
        if(button.id === 'offline'){
        const status = db.get(`time_${button.guild.id}_${button.clicker.user.id}`)
        if(!status) return button.reply.send({embed: new Discord.MessageEmbed({
        "description": "**<:ketse:" + config.emojis.offline + ">Η κατάσταση σου είναι ήδη ανενεργή<:ketse:" + config.emojis.offline + ">**",
        "color": button.guild.members.cache.get(button.clicker.user.id).displayHexColor,
        "author": {
        "name": button.clicker.user.username,
        "url": "https://discord.com/users/"+ button.clicker.user.id,
        "icon_url": button.clicker.user.displayAvatarURL()
        }
        }), ephemeral: true
        })
        if(status) {
        const fasdf = new MessageButton()
        .setID(`LEADERBOARD`)
        .setEmoji("⚡")
        .setStyle("grey");
        button.reply.send({embed: new Discord.MessageEmbed({
        "description": "**<:ketse:" + config.emojis.offline + ">Η κατάσταση σου είναι ανενεργή<:ketse:" + config.emojis.offline + ">**",
        "color": button.guild.members.cache.get(button.clicker.user.id).displayHexColor,
        "author": {
        "name": button.clicker.user.username,
        "url": "https://discord.com/users/"+ button.clicker.user.id,
        "icon_url": button.clicker.user.displayAvatarURL()
        },
        "footer": {
        "text": "Για να δεις τον συνολικό πίνακα τότε πάτα στο ⚡"
        }
        }), components: new MessageActionRow().addComponent(fasdf),ephemeral: true})
        
        const df = new Date().getTime() - status;
        
        let hours = Math.floor(df / 3600000) % 24;
        let minutes = Math.floor(df / 60000) % 60;
        let seconds = Math.floor(df / 1000) % 60; 
        if(hours) hours = `${hours}ω:`;
        if(minutes) minutes = `${minutes}λ:`;
        if(seconds) seconds = `${seconds}δ`;
        if(!hours) hours = "";
        if(!minutes) minutes = "";
        if(!seconds) seconds = "";
        button.guild.channels.cache.get(config.logs).send({embed: new Discord.MessageEmbed().setAuthor(button.clicker.user.username, button.clicker.user.displayAvatarURL(), `https://discord.com/users/${button.clicker.user.id}`).setColor("BLACK").setDescription(`**${client.users.cache.get(button.clicker.user.id)} έχει \`${hours}${minutes}${seconds}\`**`)})
        db.add(`hours_${button.guild.id}_${button.clicker.user.id}`, df)
        db.delete(`time_${button.guild.id}_${button.clicker.user.id}`)
        
        }
        }
        if(button.id === 'LEADERBOARD'){
        let arena = db.all().filter(data => data.ID.startsWith(`hours_${button.guild.id}`)).sort((a, b) => b.data - a.data)
        if(!arena) message.delete().catch(()=>{});;
        if(arena !== null){
         
        let content = "";
        
        for (let i = 0; i < arena.length; i++) {
        let user = client.users.cache.get(arena[i].ID.split('_')[2])
        let hours = Math.floor(arena[i].data / 3600000) % 24;
        let minutes = Math.floor(arena[i].data / 60000) % 60;
        let seconds = Math.floor(arena[i].data / 1000) % 60; 
        if(hours) hours = `${hours}ω:`;
        if(minutes) minutes = `${minutes}λ:`;
        if(seconds) seconds = `${seconds}δ`;
        if(!hours) hours = ``;
        if(!minutes) minutes = ``;
        if(!seconds) seconds = ``;
        
        content += `**\`${i+1}\`. ${user} έχει \`${hours}${minutes}${seconds}\`**\n`
        }
        
        
        const embed = new Discord.MessageEmbed()
        .setTitle(`**Activity Staff**`)
        .setDescription(content)
        
        .setColor(button.guild.members.cache.get(button.clicker.user.id).displayHexColor)
        
        button.reply.send({embed: embed, ephemeral: true})
        }
        
        }
})


ketse.login(config.token)